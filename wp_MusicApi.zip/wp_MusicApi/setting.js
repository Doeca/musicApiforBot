
// 配置文件
module.exports = {
    migu_cookie: 'WT_FPC=id=26b591d159ccb9db45c1612840016398:lv=1617166607084:ss=1617166393661; migu_cookie_id=25e83caa-5578-43eb-8d0c-5e5a0b179d47-n41616673107345; migu_music_status=true; migu_music_uid=91226204734; migu_music_avatar=; migu_music_nickname=%E5%92%AA%E5%92%95%E7%94%A8%E6%88%B7; migu_music_level=0; migu_music_credit_level=1; migu_music_platinum=0; migu_music_msisdn=15609665675; migu_music_email=; migu_music_passid=423322612961323579; migu_music_sid=s%3AkgVJ6LXk1UXYOBKj_hZeQYS50gaMY41X.kStBVkuYzeY12O6mTRXCFW6U30pmTMfoV1LqdipPnfY; player_stop_open=1; playlist_adding=1; addplaylist_has=1; audioplayer_new=1; playlist_change=0; add_play_now=1; mg_uem_user_id_9fbe6599400e43a4a58700a822fd57f8=c4398178-8c0e-4f3c-a696-d81e00c4ab7d; mg_uem_session_id_9fbe6599400e43a4a58700a822fd57f8=fb163c22-3588-4567-ae9b-d66c115b684d; audioplayer_open=0; audioplayer_exist=1',
    qq_cookie: 'yqq_stat=0; pgv_info=ssid=s1520392; ts_last=y.qq.com/portal/player.html; pgv_pvid=1233495754; ts_uid=5486601780; pgv_pvi=4007713792; pgv_si=s6654436352; userAction=1; _qpsvr_localtk=0.8025676546673662; yq_index=0; yplayer_open=1; player_exist=1; qqmusic_fromtag=66',
    kugou_cookie: '',
    wy_cookie : `NMTID=345db430137bc1b21670d9e860472e27; __remember_me=true; MUSIC_U=004D69BCF104865D8078E43ACC21F2C25E51921613B40563A285BB31CBC94133FA3F687BCB5B39A26F466A3FFDAC1CC470523750C44BEC705893F6FA748072398A26FD1C65C70D57CAE6DDE4370802D2EA318D3F0318888FFE8012EBA4C4FAD4F879689E27DF01C262C94FAF82A17CABF1CDA904FB4048A450283225DA9C6C53CFB44205EBFE2ABA2A96391296FD634A86E80AF5BB75ECB49718F82CFA4390B0FCE40E9B0A6A615B23C127EB7BFE3833D592228DE80403C77AD69E474712657F2A448B15ACED2D2F78869DC68FB6AACE6D9170D84A4564ED149955B6AF8F8C1F5B6417331AC81ABA969A7F45435DC1024372F9FA5F7AC5BFC4204276054BB1C8B5D353AECE08A8D350EFBF47B4E84CDA069027952656B56748C99D7B4887BF2057; __csrf=2422b75771d3afbd3cbc90cc6e379e9f; _ntes_nuid=8bb6c1e91fce61fc4bd8517828d05a5e`,
    port: '5000',//服务器端口
    QQ_uin: "XXXXXXXX",//用于自动刷新的Cookie的QQ账号，前提是 已经上传在共享仓库中，如果想要获取Vip歌曲，请传入带绿钻的QQ号 https://github-zc.github.io/wp_MusicApi/#/
    is_open_validation: false,//是否打开加密验证
    version: 'v1.5.2'
}