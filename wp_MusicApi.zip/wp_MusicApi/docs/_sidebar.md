* 快速开始
    * [关于](/)
    * [使用说明](common.md)
    * [常见问题](question.md)
* 音乐接口
    * [企鹅音乐](TX.md "wp_MusicApi 音乐接口 企鹅音乐")
    * [咪咕音乐](MG.md "wp_MusicApi 音乐接口 咪咕音乐")
    * [酷我音乐](KW.md "wp_MusicApi 音乐接口 酷我音乐")
    * [酷狗音乐](KG.md "wp_MusicApi 音乐接口 酷狗音乐")
    * [网易云音乐](WY.md "wp_MusicApi 音乐接口 网易云音乐")
* 其他接口
    * [拾荒者API](scavengers.md "wp_MusicApi 拾荒者")