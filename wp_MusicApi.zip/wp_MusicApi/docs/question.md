# 常见问题<!-- {docsify-ignore} -->



## 文档错误

由于文档是快速复制粘贴而成，文档中的可能有错误的信息，请直接在项目中提[issue](https://github.com/GitHub-ZC/wp_MusicApi/issues)